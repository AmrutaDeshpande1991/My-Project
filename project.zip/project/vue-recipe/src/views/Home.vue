<template>
    <HomePage/>
    
  </template>
  <script setup>
  import HomePage from "../components/HomePage.vue"
</script>