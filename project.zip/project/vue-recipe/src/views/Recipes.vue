<template>
    <!-- <h1>Recipes of the day</h1> -->
    <AllRecipes/>
</template>
<script setup>
import AllRecipes from "../components/AllRecipes.vue"
</script>